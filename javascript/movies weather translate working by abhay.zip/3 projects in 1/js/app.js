const get_movie_URL =
  "https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=04c35731a5ee918f014970082a0088b1&page=1";
const IMGPATH = "https://image.tmdb.org/t/p/w1280";
const SEARCHAPI =
  "https://api.themoviedb.org/3/search/movie?api_key=04c35731a5ee918f014970082a0088b1&query=";
const row = document.querySelector(".row");
const inp = document.querySelector("#inp");

const getMovies = async (movieurl) => {
  const getUrl = await fetch(movieurl);
  const data = await getUrl.json();
  showMovies(data.results);
};
getMovies(get_movie_URL);

const showMovies = async (datas) => {
  row.innerHTML = "";
  datas.forEach((data, index) => {
    const div = document.createElement("div");
    div.classList.add("col-md-4");
    div.innerHTML = `
            <div class="card shadow relative">
        <img src="${IMGPATH + data.poster_path}" class="card-img-top" alt="Movie Poster">
        <div class="card-body text-center overshadow">
          <h5 class="card-title">${data.original_title}</h5>
          <p class="text-warning">⭐ ${data.vote_average}/10</p>
          <p class="card-text">
           ${data.overview}
          </p>
        </div>
      </div>`;
    row.appendChild(div);
  });
};
inp.addEventListener("keyup", (event) => {
  let value = event.target.value;
  if (value == "") {
    getMovies(get_movie_URL);
  } else {
    getMovies(SEARCHAPI + value);
  }
});
// movies sute done here
