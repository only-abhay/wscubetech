const but = document.querySelector("#but");
const text = document.querySelector("#textInput");
const resultText = document.querySelector("#resultText")
const resultBox = document.querySelector("#resultBox")

but.addEventListener("click", async () => {
  const translate = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=hi&dt=t&q=${text.value}`;
  const res = await fetch(translate);
  const data = await res.json();
  const translation = data[0][0][0];
  resultText.innerText = translation;
  resultBox.classList.remove("d-none")
});
