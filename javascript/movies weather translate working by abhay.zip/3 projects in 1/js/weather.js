const but = document.querySelector(".but");
const inp_but = document.querySelector("#inp_but");
const weather_res = document.querySelector(".weather-result");

but.addEventListener("click", () => {
  getWeather(inp_but.value);
});

const getWeather = async (city) => {
  const APIKey = "9e1ac06a6f72dc48dc80d70b4f040583";

  const APIURL = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&units=metric&appid=${APIKey}`;

  const response = await fetch(APIURL);
  const datas = await response.json();
  showcity(datas);
};

const showcity = (datas) => {
  weather_res.innerHTML = "";
  const div = document.createElement("div");
  div.classList.add("push");
  div.innerHTML = `
       <h2>${datas.name}</h2>

<p>Temperature: ${datas.main.temp} °C</p>
<p>Weather: ${datas.weather[0].description}</p>
<p>Humidity: --${datas.main.humidity}%</p>
<p>Wind Speed: ${datas.wind.speed} km/h</p>`;

  weather_res.appendChild(div);
};
